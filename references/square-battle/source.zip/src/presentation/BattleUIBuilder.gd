## Constructs the in-battle HUD and player command controls.
##
## Splits across two canvases: `game_canvas` for player-facing HUD —
## command menu, actor/target panels, battle log — and `dev_canvas` for
## developer tooling — pause/speed, graphics menu, screenshot, save replay.
## Each canvas carries its own themed root Control from `NoggTheme`, so every
## Label/PanelContainer added beneath it inherits fonts and styling
## automatically. `BattlePresentationController` toggles the two canvases
## independently: F1 affects `dev_canvas` only.

class_name BattleUIBuilder

const BattleGraphicsMenuScript = preload("res://src/presentation/BattleGraphicsMenu.gd")
const BattleUIRefsScript = preload("res://src/presentation/BattleUIRefs.gd")
const PlayerCommandMenuScript = preload("res://src/presentation/PlayerCommandMenu.gd")
const NoggThemeScript = preload("res://src/presentation/theme/NoggTheme.gd")
const NoggWindowScript = preload("res://src/presentation/theme/NoggWindow.gd")
const TurnOrderRailScript = preload("res://src/presentation/TurnOrderRail.gd")
const DeepCardScript = preload("res://src/presentation/DeepCard.gd")

## docs/UI_DESIGN.md §8: heading + HP + ATK/DEF + SPD/MOV, and that is the
## whole content — `BattlePresentationController._renderStatusWindow()` adds
## exactly these four rows and nothing conditionally adds a fifth (Resonance
## goes into a *cell* of an existing row, not a row of its own).
##
## Was 6. The two spare rows were never filled by anything, and a NoggWindow's
## height is a function of declared capacity rather than of rows actually
## added (trait 6), so they were 52 device pixels of empty frame at the
## shipping scale — on the one element the audit found occluding the board's
## near edge, where team 1 deploys. Capacity should be a readout's real
## content, not headroom for content it does not have.
##
## Width is `NoggThemeScript.STATUS_WINDOW_WIDTH`, not redeclared here — a
## local const of a literal number could never track `NoggTheme.ui_scale` (see
## NoggTheme.gd's "Window widths" block). It stays as measured: the HP row's
## worst case ("999 / 999") and the third-column Resonance cell both need it.
const STATUS_WINDOW_CAPACITY := 4


static func build(root: Node, callbacks: Dictionary) -> BattleUIRefs:
	var refs: BattleUIRefs = BattleUIRefsScript.new()
	var game_canvas = CanvasLayer.new()
	game_canvas.name = "GameCanvas"
	game_canvas.layer = NoggThemeScript.GAME_LAYER
	game_canvas.visible = false
	root.add_child(game_canvas)
	var game_root = _buildThemedRoot(game_canvas, NoggThemeScript.build_game_theme())

	var dev_canvas = CanvasLayer.new()
	dev_canvas.name = "DevCanvas"
	dev_canvas.layer = NoggThemeScript.DEV_LAYER
	dev_canvas.visible = false
	root.add_child(dev_canvas)
	var dev_root = _buildThemedRoot(dev_canvas, NoggThemeScript.build_dev_theme())

	var topHud = HBoxContainer.new()
	topHud.set_anchors_preset(Control.PRESET_TOP_WIDE)
	topHud.offset_left = 20
	topHud.offset_top = 20
	topHud.offset_right = -20
	topHud.add_theme_constant_override("separation", 10)
	dev_root.add_child(topHud)

	var topPanel = PanelContainer.new()
	_styleHudPanel(topPanel, 6)
	topHud.add_child(topPanel)
	var topRow = HBoxContainer.new()
	topPanel.add_child(topRow)

	var playButton = Button.new()
	playButton.toggle_mode = true
	playButton.text = "Pause"
	playButton.button_pressed = true
	playButton.tooltip_text = "Pause computer-controlled turns."
	playButton.toggled.connect(callbacks["play_toggled"])
	topRow.add_child(playButton)

	var speedLabel = Label.new()
	speedLabel.text = "  Speed:"
	topRow.add_child(speedLabel)
	var speedSlider = HSlider.new()
	speedSlider.custom_minimum_size = Vector2(100, 20)
	speedSlider.min_value = 0.5
	speedSlider.max_value = 10.0
	speedSlider.step = 0.5
	speedSlider.value = 1.25
	speedSlider.tooltip_text = "CPU turn pacing."
	speedSlider.value_changed.connect(callbacks["speed_changed"])
	topRow.add_child(speedSlider)

	# A second, independent pacing control: `speedSlider` above paces how often
	# a CPU turn begins, not how long any one action's animation takes to play.
	var animSpeedLabel = Label.new()
	animSpeedLabel.text = "  Anim:"
	topRow.add_child(animSpeedLabel)
	var animSpeedSlider = HSlider.new()
	animSpeedSlider.custom_minimum_size = Vector2(100, 20)
	animSpeedSlider.min_value = 0.25
	animSpeedSlider.max_value = 4.0
	animSpeedSlider.step = 0.25
	animSpeedSlider.value = 1.0
	animSpeedSlider.tooltip_text = "Action/spell/defeat animation playback speed."
	animSpeedSlider.value_changed.connect(callbacks["anim_speed_changed"])
	topRow.add_child(animSpeedSlider)

	var newBattleButton = Button.new()
	newBattleButton.text = "New Battle"
	newBattleButton.tooltip_text = "Return to setup and discard the current battle."
	newBattleButton.pressed.connect(callbacks["new_battle_pressed"])
	topRow.add_child(newBattleButton)

	var topSpacer = Control.new()
	topSpacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	topHud.add_child(topSpacer)

	var debugPanel = PanelContainer.new()
	_styleHudPanel(debugPanel, 6)
	topHud.add_child(debugPanel)
	var debugRow = HBoxContainer.new()
	debugPanel.add_child(debugRow)
	var graphicsButton = Button.new()
	graphicsButton.toggle_mode = true
	graphicsButton.text = "Graphics"
	graphicsButton.tooltip_text = "Show or hide live rendering controls."
	debugRow.add_child(graphicsButton)
	var screenshotButton = _addActionButton(
		debugRow, "Screenshot", "Save debug/screenshot.png.", callbacks["screenshot_pressed"]
	)
	var dumpButton = _addActionButton(
		debugRow, "Save Replay", "Save setup, state, and command history.", callbacks["dump_state_pressed"]
	)

	var logButton = CheckButton.new()
	logButton.text = "Battle Log"
	logButton.tooltip_text = "Show or hide the battle event log."
	var logTogglePanel = PanelContainer.new()
	_styleHudPanel(logTogglePanel, 6)
	topHud.add_child(logTogglePanel)
	logTogglePanel.add_child(logButton)

	var turnTimer = Timer.new()
	turnTimer.wait_time = 1.0 / speedSlider.value
	turnTimer.timeout.connect(callbacks["turn_timeout"])
	root.add_child(turnTimer)

	var logPanel = PanelContainer.new()
	logPanel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	logPanel.offset_left = -380
	logPanel.offset_top = 70
	logPanel.offset_right = -20
	logPanel.offset_bottom = 470
	logPanel.visible = false
	var logStyle = StyleBoxFlat.new()
	logStyle.bg_color = Color(0, 0, 0, 0.82)
	logPanel.add_theme_stylebox_override("panel", logStyle)
	var logLabel = RichTextLabel.new()
	logLabel.scroll_following = true
	logPanel.add_child(logLabel)
	game_root.add_child(logPanel)

	var graphicsMenu = BattleGraphicsMenuScript.build(
		dev_root,
		graphicsButton,
		{
			"reset_pressed": callbacks["graphics_reset_pressed"],
			"preset_selected": callbacks["graphics_preset_selected"],
			"feature_selected": callbacks["graphics_feature_selected"],
			"look_parameter_changed": callbacks["look_parameter_changed"],
			"crt_parameter_changed": callbacks["crt_parameter_changed"],
			"ui_through_crt_toggled": callbacks["ui_through_crt_toggled"],
			"window_skin_selected": callbacks["window_skin_selected"],
			"frame_filter_selected": callbacks["frame_filter_selected"],
			"hud_layout_selected": callbacks["hud_layout_selected"],
			"ui_scale_selected": callbacks["ui_scale_selected"]
		}
	)
	graphicsButton.toggled.connect(func(pressed):
		graphicsMenu.panel.visible = pressed
		if pressed:
			logButton.button_pressed = false
	)
	logButton.toggled.connect(func(pressed):
		logPanel.visible = pressed
		if pressed:
			graphicsButton.button_pressed = false
	)

	# Docked bottom-left/bottom-right per §8, fixed size — they never resize or
	# reflow with content (item 4). Positioned directly rather than via an
	# HBoxContainer: a NoggWindow already has its own fixed size and a flex
	# container would fight that the moment the two windows' widths differ,
	# which they do not today but item 4 forbids relying on that.
	var status_window_size := Vector2(
		NoggThemeScript.STATUS_WINDOW_WIDTH, NoggThemeScript.window_height(STATUS_WINDOW_CAPACITY)
	)

	var actorWindow: NoggWindow = NoggWindowScript.new()
	game_root.add_child(actorWindow)
	actorWindow.name = "ActorWindow"
	actorWindow.set_row_capacity(STATUS_WINDOW_CAPACITY)
	actorWindow.size = status_window_size
	# Readout only. Between them these two windows cover the bottom third of the
	# viewport, including the near edge of the board where team 1 deploys, and a
	# Control consumes clicks by default — leaving those units unselectable.
	actorWindow.set_input_transparent(true)
	# Starts closed, not merely empty: `_renderStatusWindow` drives open()/close()
	# off whether a monster is showing, and starting from the Control default
	# (visible = true) would open() at construction just to immediately close()
	# the moment battle setup calls `_clearStatusWindows()` — a visible flicker
	# for a state nothing ever intended to show.
	actorWindow.visible = false

	# A plain full-rect Control, not a styled PanelContainer: the command menu
	# now draws its own NoggWindow frames and docks its windows itself per
	# docs/UI_DESIGN.md §8. A Container here would force-fit the menu into one
	# rect and a StyleBoxFlat would put a second, competing border around it.
	# Kept as a node (rather than folded away) purely so the controller's
	# existing `action_panel` visibility calls keep working untouched.
	var actionPanel = Control.new()
	actionPanel.name = "ActionPanel"
	actionPanel.set_anchors_preset(Control.PRESET_FULL_RECT)
	actionPanel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	actionPanel.visible = false
	game_root.add_child(actionPanel)

	# The prompt window's own CanvasLayer, on NoggTheme.PROMPT_LAYER — above
	# DEV_LAYER — so a player-facing message is never occluded by the dev bar
	# (BACKLOG_CRITICAL.md, "The prompt window renders behind the developer
	# HUD"). Built with the game theme, same as `game_root`, since the prompt
	# is player-facing chrome, not developer chrome — §9 must still hold even
	# though this layer number sits above DEV_LAYER.
	var promptLayer = CanvasLayer.new()
	promptLayer.name = "PromptLayer"
	promptLayer.layer = NoggThemeScript.PROMPT_LAYER
	root.add_child(promptLayer)
	var promptRoot = _buildThemedRoot(promptLayer, NoggThemeScript.build_game_theme())

	var commandMenu: PlayerCommandMenu = PlayerCommandMenuScript.new()
	commandMenu.set_anchors_preset(Control.PRESET_FULL_RECT)
	# Must run before add_child(): PlayerCommandMenu reads this once in
	# _ready(), which Godot calls synchronously as the node enters the tree.
	commandMenu.set_prompt_layer_root(promptRoot)
	actionPanel.add_child(commandMenu)

	# Reproduces, across the new CanvasLayer split, exactly the visibility
	# coupling the prompt window had for free when it was still a descendant
	# of actionPanel: an ancestor Control hidden makes every descendant
	# invisible regardless of the descendant's own `visible` flag. Now that the
	# prompt lives on a sibling CanvasLayer instead of inside actionPanel's
	# subtree, that coupling has to be stated explicitly or it silently stops
	# applying — the effective visibility becomes `promptRoot.visible AND
	# _prompt_window.visible` either way, matching the old
	# `actionPanel.visible AND _prompt_window.visible`.
	promptRoot.visible = actionPanel.visible
	actionPanel.visibility_changed.connect(func(): promptRoot.visible = actionPanel.visible)

	var targetWindow: NoggWindow = NoggWindowScript.new()
	game_root.add_child(targetWindow)
	targetWindow.name = "TargetWindow"
	targetWindow.set_row_capacity(STATUS_WINDOW_CAPACITY)
	targetWindow.size = status_window_size
	targetWindow.set_input_transparent(true)
	targetWindow.visible = false

	# The turn order is a top-docked portrait rail, not a docked window. It owns
	# the top band and the prompt sits below it: the rail is persistent and the
	# prompt is transient, so the persistent element holds the stable position
	# (docs/UI_DESIGN.md §8).
	var turnOrderRail: TurnOrderRailScript = TurnOrderRailScript.new()
	turnOrderRail.name = "TurnOrderRail"
	turnOrderRail.visible = false
	game_root.add_child(turnOrderRail)

	# The deep card positions itself: its height is a function of the unit it is
	# describing, so it has to lay out whenever its contents change rather than
	# only on `resized`, and it is deliberately not part of the docked windows'
	# reposition pass. Added after the two status windows so it draws over them
	# if a very tall card ever reaches that far down the screen.
	var deepCard: DeepCardScript = DeepCardScript.new()
	deepCard.name = "DeepCard"
	game_root.add_child(deepCard)

	# Positioned from the viewport size on `resized` rather than read once at
	# build time: `game_root.get_viewport_rect()` immediately after the canvas
	# is built is not reliably the final displayed size — the same class of
	# layout-not-settled-yet timing this codebase has hit repeatedly this
	# session (see docs/LEARNINGS.md, Process behavior). A one-shot read left
	# both windows sitting well above the true bottom margin. Mirrors
	# PlayerCommandMenu's own resized-driven `_layout_windows()`.
	##
	# Reads STATUS_WINDOW_WIDTH live on every call rather than closing over the
	# `status_window_size` computed above: that local is only correct for the
	# skin active at build time, and a later skin switch has to change what
	# this closure positions against, not just what constructed the windows.
	var reposition_status_windows := func() -> void:
		var viewport_size = game_root.get_viewport_rect().size
		var window_size := Vector2(
			NoggThemeScript.STATUS_WINDOW_WIDTH, NoggThemeScript.window_height(STATUS_WINDOW_CAPACITY)
		)
		actorWindow.position = Vector2(
			NoggThemeScript.SCREEN_MARGIN, viewport_size.y - window_size.y - NoggThemeScript.SCREEN_MARGIN
		)
		targetWindow.position = Vector2(
			viewport_size.x - window_size.x - NoggThemeScript.SCREEN_MARGIN,
			viewport_size.y - window_size.y - NoggThemeScript.SCREEN_MARGIN
		)
		# Centred, because a rail that grows and shrinks with the queue would
		# otherwise shift its whole contents every time a unit dies.
		turnOrderRail.position = Vector2(
			round((viewport_size.x - turnOrderRail.size.x) * 0.5),
			NoggThemeScript.TURN_RAIL_TOP
		)
	game_root.resized.connect(reposition_status_windows)
	reposition_status_windows.call()

	# Restyles what this function built directly (the rail's own restyle is
	# unconditional — TurnOrderRail.restyle() is cheap even when it is not
	# currently showing anything) and re-derives the size a skin switch moves,
	# which `reposition_status_windows` above does not touch. `deep_card` and
	# `command_menu` restyle themselves through their own methods; the caller
	# invokes those separately, since this builder does not own their internals.
	var restyle_status_windows := func() -> void:
		var window_size := Vector2(
			NoggThemeScript.STATUS_WINDOW_WIDTH, NoggThemeScript.window_height(STATUS_WINDOW_CAPACITY)
		)
		actorWindow.size = window_size
		actorWindow.restyle()
		targetWindow.size = window_size
		targetWindow.restyle()
		turnOrderRail.restyle()
		reposition_status_windows.call()

	refs.game_canvas = game_canvas
	refs.dev_canvas = dev_canvas
	refs.turn_timer = turnTimer
	refs.play_button = playButton
	refs.anim_speed_slider = animSpeedSlider
	refs.graphics_button = graphicsButton
	refs.graphics = graphicsMenu
	refs.actor_window = actorWindow
	refs.target_window = targetWindow
	refs.turn_order_rail = turnOrderRail
	refs.deep_card = deepCard
	refs.reposition_windows = reposition_status_windows
	refs.restyle_windows = restyle_status_windows
	refs.game_theme_root = game_root
	refs.prompt_theme_root = promptRoot
	refs.log_label = logLabel
	refs.log_panel = logPanel
	refs.action_panel = actionPanel
	refs.command_menu = commandMenu
	refs.screenshot_button = screenshotButton
	refs.dump_button = dumpButton
	return refs


## A themed root Control under a CanvasLayer. `Theme` lives on `Control`, not
## `CanvasLayer`, so every game/dev panel needs one common ancestor carrying it
## for fonts and styleboxes to cascade. `mouse_filter = IGNORE` keeps the root
## itself out of the way of clicks; children still receive input normally.
## The HUD root every game window hangs from, carrying the Theme and -- since
## the faces are bitmaps -- the texture filter.
##
## **`TEXTURE_FILTER_NEAREST` is set here and it is load-bearing.** Both faces
## are baked bitmap atlases pinned to `fixed_size` with
## `FIXED_SIZE_SCALE_INTEGER_ONLY`, so the glyph *quads* scale by whole numbers
## -- but the atlas is still sampled through the canvas item's filter, and the
## inherited default resolves to linear here regardless of
## `rendering/textures/canvas_textures/default_texture_filter` being 0. Measured
## on a rendered capture: at font size 36 the glyph pixels came back as ten
## luminance levels with 10.5% of them intermediate, and forcing nearest on the
## same string gives exactly two levels and zero intermediate pixels. The same
## was true at 24, which is what every build has shipped -- so this was blurring
## the HUD long before `ui_scale` became selectable; a bigger scale only made it
## legible as blur rather than as softness.
##
## Set on the root rather than per Label: `CanvasItem.texture_filter` defaults
## to `TEXTURE_FILTER_PARENT_NODE`, so one assignment reaches every window, row,
## cursor and card built beneath it.
static func _buildThemedRoot(canvas: CanvasLayer, theme: Theme) -> Control:
	var root = Control.new()
	root.name = "ThemedRoot"
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	root.theme = theme
	canvas.add_child(root)
	return root


static func _addActionButton(parent: Control, text: String, tooltip: String, callback: Callable) -> Button:
	var button = Button.new()
	button.text = text
	button.tooltip_text = tooltip
	button.pressed.connect(callback)
	parent.add_child(button)
	return button

static func _styleHudPanel(panel: PanelContainer, padding: int) -> void:
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.055, 0.11, 0.86)
	style.border_color = Color(0.2, 0.58, 0.9, 0.55)
	style.set_border_width_all(1)
	style.set_corner_radius_all(5)
	style.content_margin_left = padding
	style.content_margin_right = padding
	style.content_margin_top = padding
	style.content_margin_bottom = padding
	panel.add_theme_stylebox_override("panel", style)
