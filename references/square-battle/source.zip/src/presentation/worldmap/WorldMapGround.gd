## The world map's ground plane: a subdivided quad carrying the region texture.
##
## Sized from a region's tile dimensions at one tile to one world unit, and made
## deliberately LARGER than the region so the fog has somewhere to close before the art
## runs out. Where the plane extends past the art the shader substitutes the void colour;
## see `docs/WORLDMAP_DESIGN.md` §4.
##
## This node owns geometry and material only. Framing lives in `WorldMapCameraRig`, and
## the two are kept apart so the rig can be driven without a material and the material
## previewed without a camera.

class_name WorldMapGround
extends MeshInstance3D

const Uniforms = preload("res://src/presentation/worldmap/WorldMapGroundUniforms.gd")
const GROUND_SHADER = preload("res://assets/shaders/worldmap_ground.gdshader")
const CloudShadowLayer = preload("res://src/presentation/worldmap/WorldMapCloudShadows.gd")

## Curvature is a quadratic, so it needs far fewer segments than its span suggests to look
## smooth -- 64 holds up at the explorer's maximum k of 0.02 across a 250-unit plane. This
## is the only thing subdivision is for; a flat plane would be fine at 1.
const PLANE_SUBDIVISIONS := 64

## How far past the region the plane extends, as a multiple of the framing's fog end. One
## full fog length on each side guarantees geometry everywhere the fog has not yet closed,
## which is what stops the plane's own edge from appearing before the void colour can.
const FOG_MARGIN_FACTOR := 1.0

## The region's world extent in walk tiles, one world unit each. A float because art drawn on
## the 8 px cel grid does not land on a whole number of 16 px tiles.
var region_tiles := Vector2(48.0, 64.0)
## The region's own colours, used for any framing that does not name its own.
var region_fog_color := Color("cfe9f5")
var region_void_color := Color.BLACK
var region_origin := Vector2.ZERO
var region_size := Vector2(48.0, 64.0)

var _material: ShaderMaterial
var _cloudShadows: WorldMapCloudShadows


## Builds the plane for a region and applies a framing. Safe to call again with a
## different region or framing; the mesh is rebuilt only when the size actually changes.
func configure(tiles: Vector2, texture: Texture2D, framing: Dictionary,
		fogColor := Color("cfe9f5"), voidColor := Color.BLACK) -> void:
	region_fog_color = fogColor
	region_void_color = voidColor
	var complete := Uniforms.completeForRegion(framing, region_fog_color, region_void_color)
	region_tiles = tiles
	# One tile is one world unit, so the region's world size IS its tile count. A map pixel is a
	# fixed 1/16 of a unit, and the conversion happened in the catalog -- see
	# WORLDMAP_DESIGN.md section 1.
	region_size = tiles
	region_origin = Vector2.ZERO

	var margin: float = float(complete[Uniforms.K_FOG_END]) * FOG_MARGIN_FACTOR
	_rebuildMesh(region_size + Vector2(margin, margin) * 2.0)

	_ensureMaterial()
	for sampler in Uniforms.REGION_SAMPLERS:
		_material.set_shader_parameter(sampler, texture)
	Uniforms.applyToMaterial(_material, complete, region_origin, region_size)


## Receives the cast-shadow mask from `WorldMapProps`. The mask is in MAP-PIXEL space and is
## sampled with the region's own UV and its own nearest filter, which is the whole reason
## shadows land on the terrain's pixel grid rather than at arbitrary screen positions. It also
## means fog, curvature and filtering apply to a shadow for free -- it rides the ground's
## sample because it IS the ground.
func setLighting(mask: Texture2D, shadowStrength: float, light: Vector3, night: float) -> void:
	_ensureMaterial()
	_material.set_shader_parameter(Uniforms.U_SHADOW_MASK, mask)
	_material.set_shader_parameter(
		Uniforms.U_SHADOW_STRENGTH, shadowStrength if mask != null else 0.0
	)
	_material.set_shader_parameter(Uniforms.U_LIGHT_TINT, light)
	_material.set_shader_parameter(Uniforms.U_NIGHT_AMOUNT, night if mask != null else 0.0)


## The rendered cloud shadow coverage, or null before `configureCloudShadows` has run once.
## `WorldMapProps` reads this too -- a standing structure has to agree with the ground beneath
## it about where a cloud shadow falls, and there is exactly one render of the layer to agree
## on.
func cloudShadowTexture() -> Texture2D:
	return null if _cloudShadows == null else _cloudShadows.shadowTexture()


## Points the cloud shadow layer at this region and hands its texture to the material.
##
## The layer is a child of the ground rather than a sibling because it is not a thing in the
## world -- it is a channel of the ground's own surface, in the ground's own map-pixel space,
## and the only node that ever reads it is this one.
func configureCloudShadows(mapPixels: Vector2i, setID: String) -> void:
	_ensureMaterial()
	if _cloudShadows == null:
		_cloudShadows = CloudShadowLayer.new()
		_cloudShadows.name = "CloudShadows"
		add_child(_cloudShadows)
	_cloudShadows.configure(mapPixels, setID)
	_material.set_shader_parameter(Uniforms.U_CLOUD_MASK, _cloudShadows.shadowTexture())
	# The dither is anchored to MAP pixels, so the shader has to know how many there are. A
	# screen-anchored pattern swims under a panning camera, which is the fastest way to stop
	# pixel art looking like pixel art.
	_material.set_shader_parameter(Uniforms.U_MAP_SIZE, Vector2(mapPixels))


## The cloud positions `WorldMapClouds` already placed. Pushed rather than recomputed: two
## derivations of the same field is two chances for a shadow to sit under nothing.
func setCloudField(field: Array) -> void:
	if _cloudShadows != null:
		_cloudShadows.setField(field)


## How a shadowed pixel gets its colour. `multiply` darkens arithmetically and invents colours
## the palette does not contain; `palette` snaps the darkened result back to the nearest colour
## the art actually uses, so a shadowed pixel is always one somebody painted.
func setShadowPalette(mode: String, palette: PackedColorArray) -> void:
	_ensureMaterial()
	_material.set_shader_parameter(
		Uniforms.U_SHADOW_COLOR_MODE, 1 if mode == Uniforms.SHADOW_COLOR_PALETTE else 0
	)
	_material.set_shader_parameter(Uniforms.U_PALETTE_SIZE, palette.size())
	if palette.size() > 0:
		_material.set_shader_parameter(Uniforms.U_PALETTE, palette)


## Re-applies framing without touching the mesh or the texture. This is the call the debug
## scene makes on every control change, so it must stay allocation-free.
func applyFraming(framing: Dictionary) -> void:
	_ensureMaterial()
	Uniforms.applyToMaterial(
		_material,
		Uniforms.completeForRegion(framing, region_fog_color, region_void_color),
		region_origin,
		region_size
	)


## World-space rectangle the region art occupies, for the camera rig's pan clamp.
func regionRect() -> Rect2:
	return Rect2(region_origin, region_size)


func _rebuildMesh(plane_size: Vector2) -> void:
	var plane := mesh as PlaneMesh
	if plane == null:
		plane = PlaneMesh.new()
		mesh = plane
	elif plane.size.is_equal_approx(plane_size):
		return
	plane.size = plane_size
	plane.subdivide_width = PLANE_SUBDIVISIONS
	plane.subdivide_depth = PLANE_SUBDIVISIONS
	# PlaneMesh is centred on its origin; the shader locates the region in world space from
	# region_origin, so the plane is placed to keep the region centred within its margin.
	position = Vector3(
		region_origin.x + region_size.x * 0.5, 0.0, region_origin.y + region_size.y * 0.5
	)


func _ensureMaterial() -> void:
	if _material != null:
		return
	_material = ShaderMaterial.new()
	_material.shader = GROUND_SHADER
	material_override = _material
