## Deterministic low-poly shell built around presentation-supplied body bounds.

class_name IceTargetEncasementEffect
extends "res://src/presentation/effects/VfxPlayback.gd"

const IceChunkMeshFactoryScript = preload(
	"res://src/presentation/effects/IceChunkMeshFactory.gd")
const _ICE_SHADER = preload(
	"res://assets/shaders/effects/ice_target_encasement.gdshader")
const _ICE_FACET_ATLAS = preload(
	"res://assets/textures/effects/ice_strip.png")

const LAYER_SHELL_REAR := "shell_rear"
const LAYER_SHELL_SIDES := "shell_sides"
const LAYER_SHELL_FRONT := "shell_front"
const LAYER_SHELL_CAP := "shell_cap"
const LAYER_ICE_CORE := "ice_core"
const LAYER_DELIVERY_TRAIL := "delivery_trail"
const LAYER_CONTACT_ACCENTS := "contact_accents"
const LAYER_IMPACT_FLASH := "impact_flash"

var _elapsedTime := 0.0
var _totalDuration := IceTargetEncasementProfile.BATTLE_DURATION_SECONDS
var _playbackScale := 1.0
var _activeSeed := 1
var _playing := false
var _finished := true
var _disposed := false
var _autoDispose := false
var _shellBuilt := false
var _context: VfxCastContext
var _layerNodes: Dictionary = {}
var _layerVisibility := {
	LAYER_SHELL_REAR: true,
	LAYER_SHELL_SIDES: true,
	LAYER_SHELL_FRONT: true,
	LAYER_SHELL_CAP: true,
	LAYER_ICE_CORE: true,
	LAYER_DELIVERY_TRAIL: true,
	LAYER_CONTACT_ACCENTS: true,
	LAYER_IMPACT_FLASH: true,
}
var _chunkRecords: Array[Dictionary] = []
var _intactTransforms: Array[Transform3D] = []
var _brokenTransforms: Array[Transform3D] = []
var _drawCallCount := 0
var _bodyCenter := Vector3.ZERO
var _impactContactPoint := Vector3.ZERO
var _impactDirection := Vector3.LEFT
var _core: MeshInstance3D
var _coreBaseScale := Vector3.ONE
var _trailMultiMesh: MultiMesh
var _trailRecords: Array[Dictionary] = []
var _trailInstanceCount := 0
var _trailSurfacePath: Array[Vector3] = []
var _contactMultiMesh: MultiMesh
var _contactRecords: Array[Dictionary] = []
var _impactFlash: MeshInstance3D
var _impactFlashMaterial: StandardMaterial3D
var _impactFlashBaseScale := Vector3.ONE


static func createPlayback(
		parent: Node3D,
		worldPosition: Vector3,
		_elementColor: Color,
		overrides: Dictionary = {}) -> IceTargetEncasementEffect:
	var playback := IceTargetEncasementEffect.new()
	playback.name = "IceTargetEncasementEffect"
	playback.position = worldPosition
	parent.add_child(playback)
	# Before the build below: geometry and shader uniforms are assembled there,
	# so an override arriving afterwards changes nothing.
	playback.set_tunable_overrides(overrides)
	return playback


func configure_cast_context(context: VfxCastContext) -> void:
	assert(not _shellBuilt, "Ice encasement context must be configured before play.")
	context.assert_valid()
	_context = context
	if not context.target_world_positions.is_empty():
		position = context.target_world_positions[0]
	else:
		position = context.impact_world_position


func play(seed: int, mode: String) -> void:
	assert(not _disposed, "Cannot play a disposed IceTargetEncasementEffect.")
	assert(mode == MODE_REFERENCE or mode == MODE_BATTLE, "Unknown VFX playback mode.")
	_activeSeed = seed
	_totalDuration = (
		IceTargetEncasementProfile.REFERENCE_DURATION_SECONDS
		if mode == MODE_REFERENCE
		else IceTargetEncasementProfile.BATTLE_DURATION_SECONDS
	)
	if not _shellBuilt:
		_buildShell(seed)
	_elapsedTime = 0.0
	_finished = false
	_playing = true
	_applyTimeline()
	set_process(true)


func set_playback_scale(scale: float) -> void:
	_playbackScale = maxf(scale, 0.0)


func seek_normalized(time: float) -> void:
	if _disposed:
		return
	var normalizedTime := clampf(time, 0.0, 1.0)
	_elapsedTime = normalizedTime * _totalDuration
	_finished = normalizedTime >= 1.0
	_playing = not _finished
	_applyTimeline()
	if _finished:
		_finishPlayback()


func skip_to_settle() -> void:
	seek_normalized(IceTargetEncasementProfile.BALLISTIC_SKIP_FRACTION)


func get_normalized_time() -> float:
	return clampf(_elapsedTime / maxf(_totalDuration, 0.001), 0.0, 1.0)


func get_elapsed_time() -> float:
	return _elapsedTime


func get_total_duration() -> float:
	return _totalDuration


func is_finished() -> bool:
	return _finished


func dispose() -> void:
	if _disposed:
		return
	_disposed = true
	_playing = false
	set_process(false)
	if is_inside_tree() or get_parent() != null:
		queue_free()
	else:
		free()


func get_layer_names() -> Array[String]:
	return [
		LAYER_SHELL_REAR,
		LAYER_SHELL_SIDES,
		LAYER_SHELL_FRONT,
		LAYER_SHELL_CAP,
		LAYER_ICE_CORE,
		LAYER_DELIVERY_TRAIL,
		LAYER_CONTACT_ACCENTS,
		LAYER_IMPACT_FLASH,
	]


func set_layer_visible(layerName: String, visible: bool) -> void:
	if not _layerVisibility.has(layerName):
		push_warning("Unknown IceTargetEncasementEffect layer: %s" % layerName)
		return
	_layerVisibility[layerName] = visible
	var layer := _layerNodes.get(layerName) as Node3D
	if layer != null:
		layer.visible = visible


func get_live_particle_count() -> int:
	return 0


func get_live_instance_count() -> int:
	return (
		0
		if _disposed or not _shellBuilt
		else _chunkRecords.size() + _trailInstanceCount + _contactRecords.size() + 1
	)


func get_live_node_count() -> int:
	return 0 if _disposed else _countNodes(self)


func is_particle_seek_exact() -> bool:
	return true


func get_intact_transforms() -> Array[Transform3D]:
	return _intactTransforms.duplicate()


func get_broken_transforms() -> Array[Transform3D]:
	return _brokenTransforms.duplicate()


func _process(delta: float) -> void:
	if not _playing or _playbackScale <= 0.0:
		return
	_elapsedTime = minf(_elapsedTime + delta * _playbackScale, _totalDuration)
	_applyTimeline()
	if _elapsedTime >= _totalDuration:
		_finishPlayback()


func _finishPlayback() -> void:
	_finished = true
	_playing = false
	set_process(false)
	if _autoDispose and not _disposed:
		call_deferred("dispose")


func _buildShell(seed: int) -> void:
	assert(not _shellBuilt, "Ice encasement shell may only be built once.")
	var bodyBounds := VfxCastContext.DEFAULT_TARGET_BODY_BOUNDS
	if _context != null and not _context.target_body_bounds.is_empty():
		bodyBounds = _context.target_body_bounds[0]
	assert(
		bodyBounds.size.x > 0.0 and bodyBounds.size.y > 0.0 and bodyBounds.size.z > 0.0,
		"Ice encasement requires positive target body bounds."
	)
	_bodyCenter = bodyBounds.get_center()
	_configureImpactContact(bodyBounds)
	_buildLayerNodes()
	var random := RandomNumberGenerator.new()
	random.seed = seed
	_buildChunkRecords(bodyBounds, random)
	_buildChunkInstances()
	_buildCore(bodyBounds)
	_buildDeliveryTrail()
	_buildContactAccents(bodyBounds, random)
	_buildImpactFlash(bodyBounds)
	_shellBuilt = true
	assert(
		_chunkRecords.size() == IceTargetEncasementProfile.CHUNK_COUNT,
		"Ice encasement authored chunk count drifted."
	)
	assert(
		_chunkRecords.size() <= IceTargetEncasementProfile.MAX_CHUNKS,
		"Ice encasement exceeded its chunk ceiling."
	)
	assert(
		_trailInstanceCount + _contactRecords.size()
		<= IceTargetEncasementProfile.MAX_SUPPORTING_INSTANCES,
		"Ice encasement exceeded its supporting-instance ceiling."
	)
	assert(
		_chunkRecords.size()
		+ _trailInstanceCount
		+ _contactRecords.size()
		+ 1
		<= IceTargetEncasementProfile.MAX_TOTAL_GEOMETRY_INSTANCE_COUNT,
		"Ice encasement exceeded its geometry-instance ceiling."
	)
	assert(
		_countNodes(self) <= IceTargetEncasementProfile.MAX_EFFECT_NODES,
		"Ice encasement exceeded its node ceiling."
	)
	assert(
		_drawCallCount <= IceTargetEncasementProfile.MAX_DRAW_CALLS,
		"Ice encasement exceeded its draw-call ceiling."
	)


func _configureImpactContact(bounds: AABB) -> void:
	var sourceLocal := bounds.get_center() + Vector3.LEFT
	if _context != null:
		sourceLocal = to_local(_context.source_world_position)
	_impactDirection = sourceLocal - bounds.get_center()
	_impactDirection.y = 0.0
	if _impactDirection.length_squared() < 0.001:
		_impactDirection = Vector3.LEFT
	_impactDirection = _impactDirection.normalized()
	var halfExtent := bounds.size * 0.5
	_impactContactPoint = bounds.get_center() + Vector3(
		_impactDirection.x * halfExtent.x,
		0.0,
		_impactDirection.z * halfExtent.z)
	_impactContactPoint.y = (
		bounds.position.y
		+ bounds.size.y * IceTargetEncasementProfile.IMPACT_CONTACT_HEIGHT_FRACTION)


func _buildLayerNodes() -> void:
	for layerName: String in get_layer_names():
		var layer := Node3D.new()
		layer.name = layerName
		layer.visible = bool(_layerVisibility[layerName])
		add_child(layer)
		_layerNodes[layerName] = layer


func _buildChunkRecords(bounds: AABB, random: RandomNumberGenerator) -> void:
	var center := bounds.get_center()
	var width := bounds.size.x + IceTargetEncasementProfile.SHELL_CLEARANCE_U * 2.0
	var height := bounds.size.y + IceTargetEncasementProfile.SHELL_CLEARANCE_U * 2.0
	var depth := bounds.size.z + IceTargetEncasementProfile.SHELL_CLEARANCE_U * 2.0
	var thickness := maxf(
		IceTargetEncasementProfile.MIN_CHUNK_THICKNESS_U,
		minf(width, depth) * IceTargetEncasementProfile.THICKNESS_BODY_FRACTION
	)
	var jitterAmplitude := maxf(minf(width, minf(height, depth)), 0.4) * (
		IceTargetEncasementProfile.POSITION_JITTER_FRACTION
	)
	for authoredValue: Variant in IceTargetEncasementProfile.HERO_LAYOUT:
		var authored: Dictionary = authoredValue
		var layerName := String(authored["layer"])
		var positionFractions: Vector3 = authored["position"]
		var scaleFractions: Vector3 = authored["scale"]
		var rotation: Vector3 = authored["rotation"]
		var formationWindow: Vector2 = authored["formation"]
		var outward := _outwardForLayer(layerName, positionFractions)
		var scale := Vector3.ZERO
		match layerName:
			LAYER_SHELL_REAR, LAYER_SHELL_FRONT:
				scale = Vector3(
					width * scaleFractions.x,
					height * scaleFractions.y,
					thickness * scaleFractions.z)
			LAYER_SHELL_SIDES:
				scale = Vector3(
					depth * scaleFractions.z,
					height * scaleFractions.y,
					thickness * scaleFractions.x)
			LAYER_SHELL_CAP:
				scale = Vector3(
					width * scaleFractions.x,
					depth * scaleFractions.z,
					thickness * scaleFractions.y)
			_:
				assert(false, "Unknown authored ice shell layer: %s" % layerName)
		_appendChunk(
			layerName,
			String(authored["role"]),
			int(authored["kind"]),
			outward,
			center + Vector3(
				width * positionFractions.x,
				height * positionFractions.y,
				depth * positionFractions.z),
			scale,
			rotation,
			center,
			jitterAmplitude,
			formationWindow.x,
			formationWindow.y,
			random)


func _appendChunk(
		layerName: String,
		roleName: String,
		kind: int,
		outwardDirection: Vector3,
		basePosition: Vector3,
		baseScale: Vector3,
	baseRotation: Vector3,
	bodyCenter: Vector3,
	jitterAmplitude: float,
	formationStart: float,
	formationEnd: float,
	random: RandomNumberGenerator) -> void:
	var positionJitter := Vector3(
		random.randf_range(-jitterAmplitude, jitterAmplitude),
		random.randf_range(-jitterAmplitude, jitterAmplitude),
		random.randf_range(-jitterAmplitude, jitterAmplitude)
	)
	var rotationJitter := Vector3(
		random.randf_range(-1.0, 1.0),
		random.randf_range(-1.0, 1.0),
		random.randf_range(-1.0, 1.0)
	) * IceTargetEncasementProfile.ROTATION_JITTER_RADIANS
	var scaleJitter := random.randf_range(
		IceTargetEncasementProfile.SCALE_JITTER_MIN,
		IceTargetEncasementProfile.SCALE_JITTER_MAX
	)
	var intactPosition := basePosition + positionJitter
	var intactRotation := baseRotation + rotationJitter
	var intactScale := baseScale * scaleJitter
	var intactOrientation := (
		_basisFacingOutward(outwardDirection) * Basis.from_euler(intactRotation))
	var intact := Transform3D(intactOrientation.scaled(intactScale), intactPosition)
	var eruptionMix := clampf(
		inverse_lerp(
			IceTargetEncasementProfile.FIRST_ERUPTION_START_FRACTION,
			IceTargetEncasementProfile.LAST_ERUPTION_START_FRACTION,
			formationStart),
		0.0,
		1.0)
	eruptionMix = lerpf(
		IceTargetEncasementProfile.ERUPTION_CONTACT_MIX_MIN,
		IceTargetEncasementProfile.ERUPTION_CONTACT_MIX_MAX,
		eruptionMix)
	var lowerFootprint := Vector3(
		intactPosition.x, _impactContactPoint.y, intactPosition.z)
	var formationPosition := _impactContactPoint.lerp(lowerFootprint, eruptionMix)
	var broadStart := (
		IceTargetEncasementProfile.ERUPTION_LOWER_BREADTH_FRACTION
		if roleName.contains("lower")
		else IceTargetEncasementProfile.ERUPTION_START_BREADTH_FRACTION)
	var formationScaleFactors := Vector3(
		broadStart,
		IceTargetEncasementProfile.ERUPTION_START_HEIGHT_FRACTION,
		broadStart)
	if layerName == LAYER_SHELL_CAP:
		formationScaleFactors = Vector3(
			broadStart,
			broadStart,
			IceTargetEncasementProfile.ERUPTION_START_HEIGHT_FRACTION)
	var formationScale := intactScale * formationScaleFactors
	var formationOrientation := intactOrientation
	if roleName == "front_lower_slab":
		formationOrientation = (
			_basisFacingOutward(_impactDirection) * Basis.from_euler(intactRotation))
	var formation := Transform3D(
		formationOrientation.scaled(formationScale), formationPosition)
	var riseDirection := intactPosition - formationPosition
	if riseDirection.length_squared() < 0.001:
		riseDirection = Vector3.UP
	riseDirection = riseDirection.normalized()
	var overshoot := Transform3D(
		intactOrientation.scaled(
			intactScale * IceTargetEncasementProfile.ERUPTION_OVERSHOOT_SCALE),
		intactPosition
			+ riseDirection * IceTargetEncasementProfile.ERUPTION_OVERSHOOT_DISTANCE_U)
	var outward := intactPosition - bodyCenter
	if outward.length_squared() < 0.001:
		outward = Vector3.UP
	outward = outward.normalized()
	var horizontalDirection := Vector3(outward.x, 0.0, outward.z)
	if horizontalDirection.length_squared() < 0.001:
		var fallbackAngle := random.randf_range(-PI, PI)
		horizontalDirection = Vector3(cos(fallbackAngle), 0.0, sin(fallbackAngle))
	horizontalDirection = horizontalDirection.normalized().rotated(
		Vector3.UP,
		random.randf_range(
			-IceTargetEncasementProfile.BALLISTIC_DIRECTION_JITTER_RADIANS,
			IceTargetEncasementProfile.BALLISTIC_DIRECTION_JITTER_RADIANS))
	var sizeMeasure := pow(
		maxf(absf(intactScale.x * intactScale.y * intactScale.z), 0.001),
		1.0 / 3.0)
	var heavyFactor := clampf(
		(sizeMeasure - IceTargetEncasementProfile.BALLISTIC_SIZE_MIN_U)
		/ (IceTargetEncasementProfile.BALLISTIC_SIZE_MAX_U
			- IceTargetEncasementProfile.BALLISTIC_SIZE_MIN_U),
		0.0,
		1.0)
	var horizontalSpeed := lerpf(
		IceTargetEncasementProfile.BALLISTIC_HORIZONTAL_SPEED_MAX_U_PER_SECOND,
		IceTargetEncasementProfile.BALLISTIC_HORIZONTAL_SPEED_MIN_U_PER_SECOND,
		heavyFactor) * random.randf_range(0.92, 1.08)
	var verticalSpeed := (
		IceTargetEncasementProfile.BALLISTIC_VERTICAL_BASE_SPEED_U_PER_SECOND
		+ outward.y
			* IceTargetEncasementProfile.BALLISTIC_OUTWARD_VERTICAL_SPEED_U_PER_SECOND
		+ random.randf_range(
			-IceTargetEncasementProfile.BALLISTIC_VERTICAL_JITTER_U_PER_SECOND,
			IceTargetEncasementProfile.BALLISTIC_VERTICAL_JITTER_U_PER_SECOND)
		+ maxf(outward.y, 0.0)
			* IceTargetEncasementProfile.BALLISTIC_CAP_VERTICAL_BONUS_U_PER_SECOND)
	verticalSpeed = clampf(
		verticalSpeed,
		IceTargetEncasementProfile.BALLISTIC_VERTICAL_SPEED_MIN_U_PER_SECOND,
		IceTargetEncasementProfile.BALLISTIC_VERTICAL_SPEED_MAX_U_PER_SECOND)
	var angularAxis := Vector3(
		random.randf_range(-1.0, 1.0),
		random.randf_range(-1.0, 1.0),
		random.randf_range(-1.0, 1.0))
	if angularAxis.length_squared() < 0.001:
		angularAxis = Vector3.RIGHT
	angularAxis = angularAxis.normalized()
	var angularSpeed := lerpf(
		IceTargetEncasementProfile.BALLISTIC_SPIN_SPEED_MAX_RADIANS_PER_SECOND,
		IceTargetEncasementProfile.BALLISTIC_SPIN_SPEED_MIN_RADIANS_PER_SECOND,
		heavyFactor) * random.randf_range(0.90, 1.10)
	var record := {
		"layer": layerName,
		"role": roleName,
		"kind": kind,
		"formation": formation,
		"formation_start": formationStart,
		"formation_end": formationEnd,
		"overshoot": overshoot,
		"intact": intact,
		"linear_velocity": horizontalDirection * horizontalSpeed + Vector3.UP * verticalSpeed,
		"angular_axis": angularAxis,
		"angular_speed": angularSpeed,
		"departure_delay": random.randf_range(
			0.0,
			IceTargetEncasementProfile.BALLISTIC_DEPARTURE_DELAY_MAX_FRACTION),
	}
	var broken := _ballisticTransformAt(
		record, IceTargetEncasementProfile.BALLISTIC_END_FRACTION)
	record["broken"] = broken
	_chunkRecords.append(record)
	_intactTransforms.append(intact)
	_brokenTransforms.append(broken)


func _outwardForLayer(layerName: String, positionFractions: Vector3) -> Vector3:
	match layerName:
		LAYER_SHELL_REAR:
			return Vector3.FORWARD
		LAYER_SHELL_FRONT:
			return Vector3.BACK
		LAYER_SHELL_SIDES:
			return Vector3(signf(positionFractions.x), 0.0, 0.0)
		LAYER_SHELL_CAP:
			return Vector3.UP
	assert(false, "Unknown ice shell layer orientation: %s" % layerName)
	return Vector3.FORWARD


func _basisFacingOutward(outwardDirection: Vector3) -> Basis:
	var outward := outwardDirection.normalized()
	var up := Vector3.UP
	if absf(outward.dot(up)) > 0.98:
		up = Vector3.FORWARD
	return Basis.looking_at(outward, up)


func _buildChunkInstances() -> void:
	for recordIndex: int in range(_chunkRecords.size()):
		var record: Dictionary = _chunkRecords[recordIndex]
		var layerName := String(record["layer"])
		var kind := int(record["kind"])
		var multiMesh := MultiMesh.new()
		multiMesh.transform_format = MultiMesh.TRANSFORM_3D
		multiMesh.mesh = IceChunkMeshFactoryScript.create(kind)
		multiMesh.instance_count = 1
		multiMesh.set_instance_transform(0, record["formation"])
		record["multi_mesh"] = multiMesh
		record["slot"] = 0
		var instance := MultiMeshInstance3D.new()
		instance.name = String(record["role"])
		instance.multimesh = multiMesh
		var facetTile := IceTargetEncasementProfile.FACET_TILES[
			recordIndex % IceTargetEncasementProfile.FACET_TILES.size()]
		instance.material_override = _createLayerMaterial(layerName, facetTile)
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		(_layerNodes[layerName] as Node3D).add_child(instance)
		_drawCallCount += 1


func _buildCore(bounds: AABB) -> void:
	_core = MeshInstance3D.new()
	_core.name = "EncasementCore"
	var coreMesh := SphereMesh.new()
	coreMesh.radius = 0.5
	coreMesh.height = 1.0
	coreMesh.radial_segments = 8
	coreMesh.rings = 4
	_core.mesh = coreMesh
	_core.position = bounds.get_center()
	_coreBaseScale = bounds.size * IceTargetEncasementProfile.CORE_SCALE_FRACTION
	_core.scale = _coreBaseScale * IceTargetEncasementProfile.FORMATION_COMPRESSED_SCALE
	_core.material_override = _createLayerMaterial(LAYER_ICE_CORE)
	_core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	(_layerNodes[LAYER_ICE_CORE] as Node3D).add_child(_core)
	_drawCallCount += 1


func _buildDeliveryTrail() -> void:
	_buildTrailSurfacePath()
	var pathLength := _trailSurfacePathLength()
	_trailInstanceCount = clampi(
		roundi(pathLength / IceTargetEncasementProfile.TRAIL_TARGET_SPACING_U),
		IceTargetEncasementProfile.TRAIL_MIN_INSTANCE_COUNT,
		IceTargetEncasementProfile.TRAIL_MAX_INSTANCE_COUNT)
	var random := RandomNumberGenerator.new()
	random.seed = _activeSeed ^ 0x1CE5A7
	for slot: int in range(_trailInstanceCount):
		var slotFraction := float(slot) / float(maxi(_trailInstanceCount - 1, 1))
		var pathProgress := lerpf(
			IceTargetEncasementProfile.TRAIL_FIRST_PROGRESS,
			IceTargetEncasementProfile.TRAIL_LAST_PROGRESS,
			slotFraction)
		var basePosition := _trailSurfacePoint(pathProgress)
		var width := random.randf_range(
			IceTargetEncasementProfile.TRAIL_WIDTH_MIN_U,
			IceTargetEncasementProfile.TRAIL_WIDTH_MAX_U)
		var height := random.randf_range(
			IceTargetEncasementProfile.TRAIL_HEIGHT_MIN_U,
			IceTargetEncasementProfile.TRAIL_HEIGHT_MAX_U)
		var start := lerpf(
			IceTargetEncasementProfile.TRAIL_START_FRACTION,
			IceTargetEncasementProfile.TRAIL_IMPACT_FRACTION
				- IceTargetEncasementProfile.TRAIL_GROW_DURATION_FRACTION,
			slotFraction)
		_trailRecords.append({
			"position": basePosition,
			"width": width,
			"height": height,
			"rotation": Vector3(
				random.randf_range(
					-IceTargetEncasementProfile.TRAIL_TILT_JITTER_RADIANS,
					IceTargetEncasementProfile.TRAIL_TILT_JITTER_RADIANS),
				random.randf_range(
					-IceTargetEncasementProfile.TRAIL_YAW_JITTER_RADIANS,
					IceTargetEncasementProfile.TRAIL_YAW_JITTER_RADIANS),
				random.randf_range(
					-IceTargetEncasementProfile.TRAIL_TILT_JITTER_RADIANS,
					IceTargetEncasementProfile.TRAIL_TILT_JITTER_RADIANS)),
			"start": start,
			"end": start + IceTargetEncasementProfile.TRAIL_GROW_DURATION_FRACTION,
		})

	_trailMultiMesh = MultiMesh.new()
	_trailMultiMesh.transform_format = MultiMesh.TRANSFORM_3D
	_trailMultiMesh.mesh = IceChunkMeshFactoryScript.create(IceChunkMeshFactory.Kind.SPIKE)
	_trailMultiMesh.instance_count = _trailInstanceCount
	for slot: int in range(_trailInstanceCount):
		var record: Dictionary = _trailRecords[slot]
		_trailMultiMesh.set_instance_transform(
			slot,
			Transform3D(
				Basis.from_euler(record["rotation"]).scaled(Vector3.ONE * 0.001),
				record["position"]))
	var trailInstance := MultiMeshInstance3D.new()
	trailInstance.name = "GroundSpikeTrail"
	trailInstance.multimesh = _trailMultiMesh
	trailInstance.material_override = _createLayerMaterial(
		LAYER_DELIVERY_TRAIL, IceTargetEncasementProfile.FACET_TILES[6])
	trailInstance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	(_layerNodes[LAYER_DELIVERY_TRAIL] as Node3D).add_child(trailInstance)
	_drawCallCount += 1


func _buildTrailSurfacePath() -> void:
	_trailSurfacePath.clear()
	if _context != null and _context.surface_path_world_positions.size() >= 2:
		for worldPosition: Vector3 in _context.surface_path_world_positions:
			_trailSurfacePath.append(to_local(worldPosition))
	else:
		var source := Vector3(0.0, 0.0, 2.5)
		if _context != null:
			source = to_local(_context.source_world_position)
		_trailSurfacePath.append(source)
		_trailSurfacePath.append(Vector3(_bodyCenter.x, 0.0, _bodyCenter.z))
	assert(_trailSurfacePath.size() >= 2, "Ice spike trail requires two surface samples.")


func _trailSurfacePathLength() -> float:
	var total := 0.0
	for index: int in range(1, _trailSurfacePath.size()):
		var delta := _trailSurfacePath[index] - _trailSurfacePath[index - 1]
		delta.y = 0.0
		total += delta.length()
	return maxf(total, 0.001)


func _trailSurfacePoint(progress: float) -> Vector3:
	var scaledIndex := clampf(progress, 0.0, 1.0) * float(_trailSurfacePath.size() - 1)
	var lowerIndex := floori(scaledIndex)
	var upperIndex := mini(lowerIndex + 1, _trailSurfacePath.size() - 1)
	var segmentProgress := scaledIndex - float(lowerIndex)
	var point := _trailSurfacePath[lowerIndex].lerp(
		_trailSurfacePath[upperIndex], segmentProgress)
	# Use the nearest event-time surface sample for height so a spike is planted
	# on one terrain plateau rather than floating along a smoothed step slope.
	point.y = _trailSurfacePath[roundi(scaledIndex)].y
	return point


func _buildContactAccents(bounds: AABB, random: RandomNumberGenerator) -> void:
	var clusterPattern: Array[Vector2] = [
		Vector2(-0.85, 0.00), Vector2(-0.45, 0.22),
		Vector2(0.00, 0.05), Vector2(0.38, 0.32),
		Vector2(0.78, 0.12), Vector2(-0.62, 0.48),
		Vector2(0.18, 0.58), Vector2(0.62, 0.52),
	]
	assert(
		clusterPattern.size() == IceTargetEncasementProfile.CONTACT_INSTANCE_COUNT,
		"Ice contact direction count drifted from its instance count."
	)
	var contactSide := Vector3.UP.cross(_impactDirection).normalized()
	var clusterWidth := minf(bounds.size.x, bounds.size.z) * 0.52
	var clusterHeight := bounds.size.y * 0.34
	var contactSize := clampf(
		minf(bounds.size.x, minf(bounds.size.y, bounds.size.z))
		* IceTargetEncasementProfile.CONTACT_SIZE_BODY_FRACTION,
		IceTargetEncasementProfile.CONTACT_SIZE_MIN_U,
		IceTargetEncasementProfile.CONTACT_SIZE_MAX_U)
	for slot: int in range(clusterPattern.size()):
		var pattern := clusterPattern[slot]
		var direction := (
			_impactDirection
			+ contactSide * pattern.x * 0.55
			+ Vector3.UP * (0.18 + pattern.y * 0.62)).normalized()
		var start := (
			IceTargetEncasementProfile.CONTACT_START_FRACTION
			+ float(slot) * IceTargetEncasementProfile.CONTACT_STAGGER_FRACTION)
		_contactRecords.append({
			"base_position": (
				_impactContactPoint
				+ contactSide * pattern.x * clusterWidth
				+ Vector3.UP * pattern.y * clusterHeight),
			"direction": direction,
			"size": contactSize * random.randf_range(0.82, 1.12),
			"start": start,
			"end": start + IceTargetEncasementProfile.CONTACT_DURATION_FRACTION,
		})

	var contactMesh := BoxMesh.new()
	contactMesh.size = Vector3.ONE
	_contactMultiMesh = MultiMesh.new()
	_contactMultiMesh.transform_format = MultiMesh.TRANSFORM_3D
	_contactMultiMesh.mesh = contactMesh
	_contactMultiMesh.instance_count = _contactRecords.size()
	for slot: int in range(_contactRecords.size()):
		var record: Dictionary = _contactRecords[slot]
		_contactMultiMesh.set_instance_transform(
			slot,
			Transform3D(
				Basis.IDENTITY.scaled(Vector3.ONE * 0.001),
				record["base_position"]))
	var contactInstance := MultiMeshInstance3D.new()
	contactInstance.name = "ContactSquares"
	contactInstance.multimesh = _contactMultiMesh
	contactInstance.material_override = _createContactMaterial()
	contactInstance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	(_layerNodes[LAYER_CONTACT_ACCENTS] as Node3D).add_child(contactInstance)
	_drawCallCount += 1


func _buildImpactFlash(bounds: AABB) -> void:
	_impactFlash = MeshInstance3D.new()
	_impactFlash.name = "ImpactFlash"
	var flashMesh := SphereMesh.new()
	flashMesh.radius = 0.5
	flashMesh.height = 1.0
	flashMesh.radial_segments = 8
	flashMesh.rings = 4
	_impactFlash.mesh = flashMesh
	_impactFlash.position = _impactContactPoint
	_impactFlashBaseScale = Vector3.ONE * (
		minf(bounds.size.x, minf(bounds.size.y, bounds.size.z))
		* IceTargetEncasementProfile.IMPACT_FLASH_SCALE_FRACTION)
	_impactFlash.scale = _impactFlashBaseScale * 0.001
	_impactFlashMaterial = StandardMaterial3D.new()
	_impactFlashMaterial.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_impactFlashMaterial.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_impactFlashMaterial.cull_mode = BaseMaterial3D.CULL_DISABLED
	_impactFlashMaterial.no_depth_test = true
	_impactFlashMaterial.emission_enabled = true
	_impactFlashMaterial.emission = IceTargetEncasementProfile.IMPACT_FLASH_COLOR
	_impactFlashMaterial.emission_energy_multiplier = 0.7
	_impactFlashMaterial.albedo_color = Color(
		IceTargetEncasementProfile.IMPACT_FLASH_COLOR, 0.0)
	_impactFlashMaterial.render_priority = int(
		IceTargetEncasementProfile.LAYER_RENDER_PRIORITIES[LAYER_IMPACT_FLASH])
	_impactFlash.material_override = _impactFlashMaterial
	_impactFlash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	(_layerNodes[LAYER_IMPACT_FLASH] as Node3D).add_child(_impactFlash)
	_drawCallCount += 1


func _createLayerMaterial(
		layerName: String,
		facetTile: Vector2i = Vector2i(2, 1)) -> ShaderMaterial:
	var material := ShaderMaterial.new()
	material.shader = _ICE_SHADER
	var color := IceTargetEncasementProfile.SIDE_COLOR
	var opacity := IceTargetEncasementProfile.SIDE_OPACITY
	var emissionStrength := IceTargetEncasementProfile.SHELL_EMISSION_STRENGTH
	match layerName:
		LAYER_SHELL_REAR:
			color = IceTargetEncasementProfile.REAR_COLOR
			opacity = IceTargetEncasementProfile.REAR_OPACITY
		LAYER_SHELL_FRONT:
			color = IceTargetEncasementProfile.FRONT_COLOR
			opacity = IceTargetEncasementProfile.FRONT_OPACITY
		LAYER_SHELL_CAP:
			color = IceTargetEncasementProfile.CAP_COLOR
			opacity = IceTargetEncasementProfile.CAP_OPACITY
		LAYER_ICE_CORE:
			color = IceTargetEncasementProfile.CORE_COLOR
			opacity = IceTargetEncasementProfile.CORE_OPACITY
			emissionStrength = IceTargetEncasementProfile.CORE_EMISSION_STRENGTH
		LAYER_DELIVERY_TRAIL:
			color = IceTargetEncasementProfile.TRAIL_COLOR
			opacity = IceTargetEncasementProfile.TRAIL_OPACITY
			emissionStrength = IceTargetEncasementProfile.TRAIL_EMISSION_STRENGTH
		LAYER_CONTACT_ACCENTS:
			color = IceTargetEncasementProfile.CONTACT_COLOR
	material.set_shader_parameter("base_color", color)
	material.set_shader_parameter("shadow_color", IceTargetEncasementProfile.SHADOW_COLOR)
	material.set_shader_parameter("opacity", opacity)
	material.set_shader_parameter("emission_strength", emissionStrength)
	material.set_shader_parameter("facet_atlas", _ICE_FACET_ATLAS)
	material.set_shader_parameter("facet_tile", Vector2(facetTile))
	material.set_shader_parameter(
		"facet_atlas_pixel_size", IceTargetEncasementProfile.FACET_ATLAS_PIXEL_SIZE)
	material.set_shader_parameter(
		"facet_tile_pixel_size", IceTargetEncasementProfile.FACET_TILE_PIXEL_SIZE)
	material.set_shader_parameter(
		"facet_color_strength", IceTargetEncasementProfile.FACET_COLOR_STRENGTH)
	material.render_priority = int(IceTargetEncasementProfile.LAYER_RENDER_PRIORITIES[layerName])
	return material


func _createContactMaterial() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.albedo_color = IceTargetEncasementProfile.CONTACT_COLOR
	material.emission_enabled = true
	material.emission = IceTargetEncasementProfile.CONTACT_COLOR
	material.emission_energy_multiplier = 0.55
	material.render_priority = int(
		IceTargetEncasementProfile.LAYER_RENDER_PRIORITIES[LAYER_CONTACT_ACCENTS])
	return material


func _applyTimeline() -> void:
	if not _shellBuilt:
		return
	var normalizedTime := get_normalized_time()
	for record: Dictionary in _chunkRecords:
		var multiMesh := record["multi_mesh"] as MultiMesh
		assert(multiMesh != null, "Ice encasement chunk is missing its stable MultiMesh slot.")
		multiMesh.set_instance_transform(
			int(record["slot"]), _chunkTransformAt(record, normalizedTime))
	_applyCoreTimeline(normalizedTime)
	_applyDeliveryTrailTimeline(normalizedTime)
	_applyContactTimeline(normalizedTime)
	_applyImpactFlashTimeline(normalizedTime)
	for layerName: String in get_layer_names():
		var layer := _layerNodes.get(layerName) as Node3D
		if layer != null:
			layer.visible = bool(_layerVisibility[layerName])


func _chunkTransformAt(record: Dictionary, normalizedTime: float) -> Transform3D:
	var formation: Transform3D = record["formation"]
	var overshoot: Transform3D = record["overshoot"]
	var intact: Transform3D = record["intact"]
	if normalizedTime < float(record["formation_end"]):
		var formationProgress := _windowProgress(
			normalizedTime, float(record["formation_start"]), float(record["formation_end"]))
		if formationProgress < IceTargetEncasementProfile.ERUPTION_OVERSHOOT_PROGRESS:
			var riseProgress := _smoothstep01(
				formationProgress / IceTargetEncasementProfile.ERUPTION_OVERSHOOT_PROGRESS)
			return _interpolateTransform(
				formation, overshoot, riseProgress, riseProgress, riseProgress)
		var settleProgress := _smoothstep01(
			(formationProgress - IceTargetEncasementProfile.ERUPTION_OVERSHOOT_PROGRESS)
			/ (1.0 - IceTargetEncasementProfile.ERUPTION_OVERSHOOT_PROGRESS))
		return _interpolateTransform(
			overshoot, intact, settleProgress, settleProgress, settleProgress)
	if normalizedTime <= IceTargetEncasementProfile.COMPLETED_HOLD_END_FRACTION:
		return intact
	return _ballisticTransformAt(record, normalizedTime)


## Analytic projectile motion keeps every seek exact. Scale is deliberately
## constant: a fracture launches the held pieces, it never inflates or eases
## them toward an authored endpoint.
func _ballisticTransformAt(record: Dictionary, normalizedTime: float) -> Transform3D:
	var intact: Transform3D = record["intact"]
	var launchFraction := (
		IceTargetEncasementProfile.BALLISTIC_START_FRACTION
		+ float(record["departure_delay"]))
	if normalizedTime <= launchFraction:
		return intact
	var normalizedFlightTime := (
		(normalizedTime - launchFraction)
		/ (IceTargetEncasementProfile.BALLISTIC_END_FRACTION
			- IceTargetEncasementProfile.BALLISTIC_START_FRACTION))
	var flightSeconds := maxf(normalizedFlightTime, 0.0) * (
		IceTargetEncasementProfile.BALLISTIC_REFERENCE_SECONDS)
	var linearVelocity: Vector3 = record["linear_velocity"]
	var gravity := Vector3.DOWN * (
		IceTargetEncasementProfile.BALLISTIC_GRAVITY_U_PER_SECOND_SQUARED)
	var position := (
		intact.origin
		+ linearVelocity * flightSeconds
		+ gravity * (0.5 * flightSeconds * flightSeconds))
	var angularAxis: Vector3 = record["angular_axis"]
	var angularRadians := float(record["angular_speed"]) * flightSeconds
	var spin := Basis(Quaternion(angularAxis, angularRadians))
	var intactRotation := intact.basis.orthonormalized()
	var intactScale := intact.basis.get_scale()
	return Transform3D((spin * intactRotation).scaled(intactScale), position)


func _applyCoreTimeline(normalizedTime: float) -> void:
	if _core == null:
		return
	var coreFactor := IceTargetEncasementProfile.FORMATION_COMPRESSED_SCALE
	if normalizedTime < IceTargetEncasementProfile.CORE_FORMATION_START_FRACTION:
		coreFactor = IceTargetEncasementProfile.FORMATION_COMPRESSED_SCALE
	elif normalizedTime < IceTargetEncasementProfile.CORE_FORMATION_END_FRACTION:
		coreFactor = lerpf(
			IceTargetEncasementProfile.FORMATION_COMPRESSED_SCALE,
			1.0,
			_smoothstep01(_windowProgress(
				normalizedTime,
				IceTargetEncasementProfile.CORE_FORMATION_START_FRACTION,
				IceTargetEncasementProfile.CORE_FORMATION_END_FRACTION)))
	elif normalizedTime <= IceTargetEncasementProfile.COMPLETED_HOLD_END_FRACTION:
		coreFactor = 1.0
	elif normalizedTime < IceTargetEncasementProfile.FRACTURE_IMPULSE_END_FRACTION:
		var impulseProgress := _windowProgress(
			normalizedTime,
			IceTargetEncasementProfile.FRACTURE_IMPULSE_START_FRACTION,
			IceTargetEncasementProfile.FRACTURE_IMPULSE_END_FRACTION)
		coreFactor = 1.0 + sin(impulseProgress * PI) * 0.14
	elif normalizedTime < IceTargetEncasementProfile.CORE_BREAK_END_FRACTION:
		coreFactor = lerpf(
			1.0,
			IceTargetEncasementProfile.FORMATION_COMPRESSED_SCALE,
			_smoothstep01(_windowProgress(
				normalizedTime,
				IceTargetEncasementProfile.FRACTURE_IMPULSE_END_FRACTION,
				IceTargetEncasementProfile.CORE_BREAK_END_FRACTION)))
	_core.scale = _coreBaseScale * coreFactor
	_core.visible = coreFactor > 0.025


func _applyDeliveryTrailTimeline(normalizedTime: float) -> void:
	if _trailMultiMesh == null:
		return
	for slot: int in range(_trailRecords.size()):
		var record: Dictionary = _trailRecords[slot]
		var growth := _smoothstep01(_windowProgress(
			normalizedTime, float(record["start"]), float(record["end"])))
		var fadeStart := (
			IceTargetEncasementProfile.TRAIL_IMPACT_FRACTION
			+ float(slot) * IceTargetEncasementProfile.TRAIL_FADE_STAGGER_FRACTION)
		var fade := _smoothstep01(_windowProgress(
			normalizedTime, fadeStart, IceTargetEncasementProfile.TRAIL_FADE_END_FRACTION))
		var visibleScale := maxf(growth * (1.0 - fade), 0.001)
		var width: float = float(record["width"]) * visibleScale
		var height: float = float(record["height"]) * visibleScale
		_trailMultiMesh.set_instance_transform(
			slot,
			Transform3D(
				Basis.from_euler(record["rotation"]).scaled(
					Vector3(width, height, width)),
				record["position"]))


func _applyContactTimeline(normalizedTime: float) -> void:
	if _contactMultiMesh == null:
		return
	for slot: int in range(_contactRecords.size()):
		var record: Dictionary = _contactRecords[slot]
		var progress := _windowProgress(
			normalizedTime, float(record["start"]), float(record["end"]))
		var visibility := 0.0
		if normalizedTime > float(record["start"]) and normalizedTime < float(record["end"]):
			if progress < 0.15:
				visibility = _smoothstep01(progress / 0.15)
			elif progress < 0.80:
				visibility = 1.0
			else:
				visibility = 1.0 - _smoothstep01((progress - 0.80) / 0.20)
		var position: Vector3 = record["base_position"]
		position += (
			(record["direction"] as Vector3)
			* IceTargetEncasementProfile.CONTACT_OUTWARD_DISTANCE_U
			* _easeOutCubic(progress))
		var size := float(record["size"]) * maxf(visibility, 0.001)
		_contactMultiMesh.set_instance_transform(
			slot,
			Transform3D(
				Basis.IDENTITY.scaled(Vector3(size, size, size * 0.22)),
				position))


func _applyImpactFlashTimeline(normalizedTime: float) -> void:
	if _impactFlash == null or _impactFlashMaterial == null:
		return
	var progress := _windowProgress(
		normalizedTime,
		IceTargetEncasementProfile.IMPACT_FLASH_START_FRACTION,
		IceTargetEncasementProfile.IMPACT_FLASH_END_FRACTION)
	var visibility := sin(progress * PI)
	if (
		normalizedTime <= IceTargetEncasementProfile.IMPACT_FLASH_START_FRACTION
		or normalizedTime >= IceTargetEncasementProfile.IMPACT_FLASH_END_FRACTION
	):
		visibility = 0.0
	_impactFlash.scale = _impactFlashBaseScale * maxf(visibility, 0.001)
	var flashColor := IceTargetEncasementProfile.IMPACT_FLASH_COLOR
	flashColor.a = IceTargetEncasementProfile.IMPACT_FLASH_MAX_ALPHA * visibility
	_impactFlashMaterial.albedo_color = flashColor
	_impactFlashMaterial.emission_energy_multiplier = 0.35 + visibility * 0.65
	_impactFlash.visible = visibility > 0.01


func _interpolateTransform(
		from: Transform3D,
		to: Transform3D,
		positionProgress: float,
		rotationProgress: float,
		scaleProgress: float) -> Transform3D:
	var fromRotation := from.basis.orthonormalized().get_rotation_quaternion()
	var toRotation := to.basis.orthonormalized().get_rotation_quaternion()
	var rotation := fromRotation.slerp(toRotation, clampf(rotationProgress, 0.0, 1.0))
	var scale := from.basis.get_scale().lerp(
		to.basis.get_scale(), clampf(scaleProgress, 0.0, 1.0))
	var origin := from.origin.lerp(to.origin, clampf(positionProgress, 0.0, 1.0))
	return Transform3D(Basis(rotation).scaled(scale), origin)


func _windowProgress(value: float, start: float, end: float) -> float:
	return clampf((value - start) / maxf(end - start, 0.0001), 0.0, 1.0)


func _smoothstep01(value: float) -> float:
	var clamped := clampf(value, 0.0, 1.0)
	return clamped * clamped * (3.0 - 2.0 * clamped)


func _easeOutCubic(value: float) -> float:
	var inverse := 1.0 - clampf(value, 0.0, 1.0)
	return 1.0 - inverse * inverse * inverse




func _countNodes(node: Node) -> int:
	var total := 1
	for child: Node in node.get_children():
		total += _countNodes(child)
	return total
